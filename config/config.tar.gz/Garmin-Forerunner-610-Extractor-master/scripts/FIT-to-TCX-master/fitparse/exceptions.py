class FitError(Exception):
    pass


class FitParseError(FitError):
    pass


class FitParseComplete(Exception):
    pass
